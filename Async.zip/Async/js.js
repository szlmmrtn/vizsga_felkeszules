var title = document.title;
console.log(title);
document.getElementById("h1").innerHTML = title ;